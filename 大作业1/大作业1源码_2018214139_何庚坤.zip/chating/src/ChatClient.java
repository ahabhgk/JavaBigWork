import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class ClientThread extends Thread {
  Socket socket;
  ClientThread(Socket s) {
    socket = s;
  }
  @Override
  public void run() {
    try {
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
      String massage;

      while (true) {
        massage = reader.readLine();
        writer.println(massage);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

public class ChatClient {
  public static void main(String[] args) throws IOException {
    Socket socket = new Socket("127.0.0.1", 7000);
    new ClientThread(socket).start();
    BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    String massage;
    while ((massage = reader.readLine()) != null) {
      System.out.println(massage);
    }
  }
}
