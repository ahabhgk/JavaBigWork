import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class ServerThread extends Thread {
  public Socket client;
  public ArrayList<Socket> clients;
  private BufferedReader bufferedReader;
  private PrintWriter printWriter;

  ServerThread(Socket client, ArrayList<Socket> clients) {
    this.client = client;
    this.clients = clients;
  }

  @Override
  public void run() {
    try {
      bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
      int user = clients.indexOf(client);
      String massage = "Welcome user " + user + " !!!";
      sendMassage(massage);

      String chatMsg;
      while (!"exit".equals(chatMsg = bufferedReader.readLine())) {
        chatMsg = "User " + user + " : " + chatMsg;
        sendMassage(chatMsg);
      }
//      sendMassage("User " + user + " exited...");
//      bufferedReader.close();
//      client.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void sendMassage(String massage) {
    try {
      System.out.println(massage);

      for (int i = 0; i < clients.size(); i++) {
        printWriter = new PrintWriter(clients.get(i).getOutputStream(), true);
        printWriter.println(massage);
        printWriter.flush();
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

public class ChatServer {
  public static void main(String[] args) {
    try {
      ServerSocket serverSocket = new ServerSocket(7000);
      ArrayList<Socket> clients = new ArrayList<Socket>();
      System.out.println("聊天服务器启动，端口：7000。。。");
      while (true) {
        Socket client = serverSocket.accept();
        clients.add(client);
        new ServerThread(client, clients).start();
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
