package controller;

import model.CommodityModel;
import utils.DB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "LoginServlet", urlPatterns = "/LoginServlet")
public class LoginServlet extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    req.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));
    resp.setContentType("text/html");
    resp.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));
    DB dbUtil = new DB();
    try {
      if (dbUtil.checkUser(req.getParameter("username"), req.getParameter("password"))) {
        try {
          ArrayList<CommodityModel> commodities = dbUtil.getAllCommodities();
          System.out.println(commodities);
          HttpSession session = req.getSession();
          session.setMaxInactiveInterval(3600);
          session.setAttribute("commodities", commodities);
          resp.getWriter().println("<!DOCTYPE html>" +
              "  <html lang=\"en\">" +
              "  <head>" +
              "    <meta charset=\"UTF-8\">" +
              "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
              "    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">" +
              "    <link href=\"./assets/styles.css\" rel=\"stylesheet\">" +
              "<title>" +
              "登录成功" +
              "</title>" +
              "</head>" +
              "<body class=\"container\">" +
              "<img class=\"login__success\" src=\"./assets/images/success.png\" />" +
              "登录成功" +
              "<a href=\"commodities.jsp\" class=\"login__form--link\">查询商品</a>" +
              "</body>" +
              "</html>");
        } catch (SQLException | ClassNotFoundException e) {
          e.printStackTrace();
        }
      } else {
        resp.getWriter().println("账号或密码错误");
        req.getRequestDispatcher("src/view/login.jsp").forward(req, resp);
      }
    } catch (SQLException | ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doGet(req, resp);
  }
}
