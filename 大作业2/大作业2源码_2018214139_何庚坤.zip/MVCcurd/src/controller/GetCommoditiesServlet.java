package controller;

import model.CommodityModel;
import utils.DB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "GetCommoditiesServlet", urlPatterns = "/GetCommoditiesServlet")
public class GetCommoditiesServlet extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    req.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));
    resp.setContentType("text/html");
    resp.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));

    String code = req.getParameter("code");

    DB dbUtil = new DB();
    try {
      ArrayList<CommodityModel> commodities = dbUtil.getCommoditiesByCode(code);
      HttpSession session = req.getSession();
      session.setMaxInactiveInterval(3600);
      session.setAttribute("commodities",commodities);
      session.setAttribute("code",code);
      resp.sendRedirect(req.getContextPath()+"/commodities.jsp");
    } catch (SQLException | ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doGet(req, resp);
  }
}
