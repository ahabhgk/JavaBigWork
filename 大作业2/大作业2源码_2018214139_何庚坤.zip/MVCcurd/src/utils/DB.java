package utils;

import model.CommodityModel;
import model.UserModel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DB {
  private final String dbClassName = "com.mysql.jdbc.Driver";
  private final String url = "jdbc:mysql://localhost:3306/MVCcurd?useSSL=false";
  private final String user = "root";
  private final String password = "Hgk20180921";

  public Connection getConnection() throws SQLException, ClassNotFoundException {
    Class.forName(dbClassName);
    return DriverManager.getConnection(url, user, password);
  }

  public ArrayList<CommodityModel> getAllCommodities() throws SQLException, ClassNotFoundException {
    Statement statement = getConnection().createStatement();
    ResultSet resultSet = statement.executeQuery("select * from commodity");
    ArrayList<CommodityModel> list = new ArrayList<CommodityModel>();
    while(resultSet.next()){
      CommodityModel g = new CommodityModel();
      g.setId(resultSet.getInt("id"));
      g.setSort(resultSet.getString("sort"));
      g.setCode(resultSet.getString("code"));
      g.setName(resultSet.getString("name"));
      g.setPlace(resultSet.getString("place"));
      g.setPrice(resultSet.getString("price"));
      g.setDescription(resultSet.getString("description"));
      list.add(g);
    }
    return list;
  }

  public ArrayList<CommodityModel> getCommoditiesByCode(String code) throws SQLException, ClassNotFoundException {
    Statement statement = getConnection().createStatement();
    ResultSet resultSet = statement.executeQuery("select * from commodity where code = '" + code + "'");
    ArrayList<CommodityModel> list = new ArrayList<CommodityModel>();
    while(resultSet.next()){
      CommodityModel g = new CommodityModel();
      g.setId(resultSet.getInt("id"));
      g.setSort(resultSet.getString("sort"));
      g.setCode(resultSet.getString("code"));
      g.setName(resultSet.getString("name"));
      g.setPlace(resultSet.getString("place"));
      g.setPrice(resultSet.getString("price"));
      g.setDescription(resultSet.getString("description"));
      list.add(g);
    }
    return list;
  }

  public boolean checkUser(String username, String password) throws SQLException, ClassNotFoundException {
    Statement statement = getConnection().createStatement();
    ResultSet resultSet = statement.executeQuery(" select username,password from user where username ='" + username + "'and password = '" + password + "' ");
    UserModel g = null;
    while(resultSet.next()){
      g = new UserModel();
      g.setUsername(resultSet.getString("username"));
      g.setPassword(resultSet.getString("password"));
    }
    return g != null;
  }
}
